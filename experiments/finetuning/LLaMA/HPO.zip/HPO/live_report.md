# Live HPO Report

Updated: 2026-05-08T21:01:36
Model: models/Llama-3.2-3B-Instruct
Dataset: combined_80_20_split (500 train / 200 val)
Fixed batch size: 4
Fixed LoRA rank: 16
Max sequence length: 1024
Completed trials: 8 / 8

## Best So Far
- Trial: 4
- Eval loss: 1.0012
- Learning rate: 4.62e-04
- Warmup ratio: 0.082
- Weight decay: 0.0109

## Completed Trials
| Trial | Learning Rate | Warmup | Weight Decay | Eval Loss |
|:---:|:---:|:---:|:---:|:---:|
| 4 | 4.62e-04 | 0.082 | 0.0109 | 1.0012 |
| 3 | 2.61e-04 | 0.053 | 0.0582 | 1.0413 |
| 1 | 1.58e-04 | 0.073 | 0.0094 | 1.1096 |
| 6 | 7.31e-05 | 0.094 | 0.0367 | 1.4319 |
| 0 | 5.61e-05 | 0.193 | 0.0439 | 1.5802 |
| 5 | 2.33e-05 | 0.096 | 0.0315 | 2.2100 |
| 7 | 1.90e-05 | 0.094 | 0.0220 | 2.3755 |
| 2 | 1.31e-05 | 0.180 | 0.0361 | 2.5885 |
